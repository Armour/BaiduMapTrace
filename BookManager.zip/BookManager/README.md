#食用说明
1. 需要的依赖
	* nodejs (github.com）
	* bower (npm install bower -g)
	* express (npm install express -g)
	* mongodb 
2. 进入文件夹

	~~~
	npm install (会根据json文件自动适配）
	bower install（会根据json文件自动适配）
	~~~

3. 